<!-- footer.php -->

<footer class="bg-dark text-white text-center py-3 mt-5">
    &copy; <?php echo date('Y'); ?> Car Rental Service. All rights reserved.
</footer>
